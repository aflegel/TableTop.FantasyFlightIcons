# Star Wars RPG Icons

This webfont includes icons for Star Wars RPG systems "Edge of the Empire", "Age of Rebellion", and "Force and Destiny"; as well as Star Wars Imperial Assault and Star Wars Armada.

## Contributions and Issues

Please visit the github issues section to request additional icons or to report issues with existing icons.
